from machine import Pin, I2C
import time
import math

# MPU6050 constants
MPU6050_ADDR = 0x68
MPU6050_PWR_MGMT_1 = 0x6B
MPU6050_ACCEL_XOUT_H = 0x3B
MPU6050_ACCEL_YOUT_H = 0x3D
MPU6050_ACCEL_ZOUT_H = 0x3F
MPU6050_TEMP_OUT_H = 0x41
MPU6050_GYRO_XOUT_H = 0x43
MPU6050_GYRO_YOUT_H = 0x45
MPU6050_GYRO_ZOUT_H = 0x47

# Initialize I2C
i2c = I2C(0, scl=Pin(5), sda=Pin(4))

# Wake up MPU6050
i2c.writeto_mem(MPU6050_ADDR, MPU6050_PWR_MGMT_1, b'\x00')

def read_word(adr):
    high = i2c.readfrom_mem(MPU6050_ADDR, adr, 1)[0]
    low = i2c.readfrom_mem(MPU6050_ADDR, adr + 1, 1)[0]
    val = (high << 8) + low
    if val >= 0x8000:
        return -((65535 - val) + 1)
    else:
        return val

def read_mpu6050():
    accel_x = read_word(MPU6050_ACCEL_XOUT_H)
    accel_y = read_word(MPU6050_ACCEL_YOUT_H)
    accel_z = read_word(MPU6050_ACCEL_ZOUT_H)
    temp = read_word(MPU6050_TEMP_OUT_H)
    gyro_x = read_word(MPU6050_GYRO_XOUT_H)
    gyro_y = read_word(MPU6050_GYRO_YOUT_H)
    gyro_z = read_word(MPU6050_GYRO_ZOUT_H)

    accel_x = accel_x / 16384.0
    accel_y = accel_y / 16384.0
    accel_z = accel_z / 16384.0
    temp = temp / 340.0 + 36.53
    gyro_x = gyro_x / 131.0
    gyro_y = gyro_y / 131.0
    gyro_z = gyro_z / 131.0

    return accel_x, accel_y, accel_z, temp, gyro_x, gyro_y, gyro_z

def is_falling(accel_x, accel_y, accel_z, threshold=2.5):
    # Calculate the magnitude of the acceleration vector
    magnitude = math.sqrt(accel_x**2 + accel_y**2 + accel_z**2)
    # Check if the magnitude exceeds the threshold
    return magnitude > threshold

while True:
    accel_x, accel_y, accel_z, temp, gyro_x, gyro_y, gyro_z = read_mpu6050()
    falling = is_falling(accel_x, accel_y, accel_z)
    
    print(f"Acceleration X: {accel_x:.2f} m/s^2, Y: {accel_y:.2f} m/s^2, Z: {accel_z:.2f} m/s^2")
    print(f"Gyro X: {gyro_x:.2f} rad/s, Y: {gyro_y:.2f} rad/s, Z: {gyro_z:.2f} rad/s")
    print(f"Temperature: {temp:.2f} °C")
    print("Status: Falling" if falling else "Status: Not Falling")
    print("")
    time.sleep(0.5)
